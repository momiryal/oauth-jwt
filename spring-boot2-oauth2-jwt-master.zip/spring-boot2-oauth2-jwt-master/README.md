OAuth2 + JWT using Spring Boot 2 / Spring Security 5
---

Read more http://blog.marcosbarbero.com/centralized-authorization-jwt-spring-boot2/